<?php
include('db_config.php');

// Inserir Cliente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cadastrar_cliente'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    $sql = "INSERT INTO Clientes (Nome, Email, Telefone) VALUES (:nome, :email, :telefone)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telefone', $telefone);
    $stmt->execute();
    echo "<script>alert('Cliente cadastrado com sucesso!');</script>";
}

// Buscar todos os chamados
$chamados = $pdo->query("SELECT * FROM Chamados")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Chamados</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Cadastro de Cliente</h1>
    <form action="index.php" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
        
        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="telefone">Telefone:</label>
        <input type="tel" id="telefone" name="telefone" required>

        <button type="submit" name="cadastrar_cliente">Cadastrar Cliente</button>
    </form>

    <h2>Gerenciamento de Chamados</h2>
    <div>
        <label for="filtro_status">Filtro por Status:</label>
        <select id="filtro_status">
            <option value="Aberto">Aberto</option>
            <option value="Em Andamento">Em Andamento</option>
            <option value="Resolvido">Resolvido</option>
        </select>

        <label for="filtro_criticidade">Filtro por Criticidade:</label>
        <select id="filtro_criticidade">
            <option value="Baixa">Baixa</option>
            <option value="Média">Média</option>
            <option value="Alta">Alta</option>
        </select>
    </div>

    <div id="lista_chamados">
        <?php foreach ($chamados as $chamado): ?>
            <div class="chamado">
                <p><strong>ID:</strong> <?= $chamado['ID'] ?></p>
                <p><strong>Descrição:</strong> <?= $chamado['Descricao'] ?></p>
                <p><strong>Status:</strong> <?= $chamado['Status'] ?></p>
                <p><strong>Criticidade:</strong> <?= $chamado['Criticidade'] ?></p>
                <p><strong>Data Abertura:</strong> <?= $chamado['Data_Abertura'] ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <script src="script.js"></script>
</body>
</html>
